        $.letItSnow('.let-it-snow', {
            stickyFlakes: 'lis-flake--js',
            makeFlakes: true,
            sticky: false
        });

            
            $('#titlehead')
               .fitText(1.2)
               .textillate({ in: { effect: 'none' }
            });

            $('#descript')
                .fitText(3)
                .textillate({ in: { effect: 'none' }
            });

            footext
            $('#footext')
                .fitText(5)
                .textillate({ in: { effect: 'none' }
            });